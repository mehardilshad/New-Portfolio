import React from 'react'
import styled from 'styled-components'

function Modal() {
  return (
    <MainContainer>
        <CardContainer>
          <Header>
            <Title>Edit Step</Title>
            <CloseContainer>
                <img src={require('../../src/Images/close.png')} alt="Close" />
            </CloseContainer>
          </Header>
        </CardContainer>
    </MainContainer>
  )
}

export default Modal

const MainContainer = styled.div`
  background: grey;
  width: 100%;
  height: 100vh;
`; 
const CardContainer = styled.div`
  width: 40%;
  margin: 0 auto;
  background: #fff;

`; 
const Header = styled.div`
  display: flex;
  justify-content: space-between;
`; 
const Title = styled.h4``; 
const CloseContainer = styled.div`
  width: 4%;
`; 