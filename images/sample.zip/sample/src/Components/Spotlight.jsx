import React from "react";
import styled from "styled-components";

function Spotlight() {
    return (
        < >
            <MainContainer className="Spotlight">
                <Conatiner>
                    <Header>Title</Header>
                    <Header>Display Index</Header>
                </Conatiner>
                <Lis>
                    <Heading>Login</Heading>
                    <Box>1</Box>
                    <Right>
                        <Radio>
                            <label class="switch">
                                <input type="checkbox" />
                                <span class="slider round"></span>
                            </label>
                        </Radio>
                        <EditContainer>
                            <img
                                src={require("../Images/pen-solid.svg").default}
                                alt=""
                            />
                        </EditContainer>
                    </Right>
                </Lis>
                <Lis>
                    <Heading>Billing</Heading>
                    <Box>1</Box>
                    <Right>
                        <Radio>
                            <label class="switch">
                                <input type="checkbox" />
                                <span class="slider round"></span>
                            </label>
                        </Radio>
                        <EditContainer>
                            <img
                                src={require("../Images/pen-solid.svg").default}
                                alt=""
                            />
                        </EditContainer>
                    </Right>
                </Lis>
                <Lis>
                    <Heading>Shipping</Heading>
                    <Box>2</Box>
                    <Right>
                        <Radio>
                            <label class="switch">
                                <input type="checkbox" />
                                <span class="slider round"></span>
                            </label>
                        </Radio>
                        <EditContainer>
                            <img
                                src={require("../Images/pen-solid.svg").default}
                                alt=""
                            />
                        </EditContainer>
                    </Right>
                </Lis>
                <Lis>
                    <Heading>Order Info</Heading>
                    <Box>3</Box>
                    <Right>
                        <Radio>
                            <label class="switch">
                                <input type="checkbox" />
                                <span class="slider round"></span>
                            </label>
                        </Radio>
                        <EditContainer>
                            <img
                                src={require("../Images/pen-solid.svg").default}
                                alt=""
                            />
                        </EditContainer>
                    </Right>
                </Lis>
                <Lis>
                    <Heading>Payment</Heading>
                    <Box>4</Box>
                    <Right>
                        <Radio>
                            <label class="switch">
                                <input type="checkbox" />
                                <span class="slider round"></span>
                            </label>
                        </Radio>
                        <EditContainer>
                            <img
                                src={require("../Images/pen-solid.svg").default}
                                alt=""
                            />
                        </EditContainer>
                    </Right>
                </Lis>
            </MainContainer>
            <Buttons>
                    <Button className="first">Reset</Button>
                    <Button>Save Changes</Button>
                </Buttons>
        </>
    );
}

export default Spotlight;

const MainContainer = styled.div`
    padding: 25px 0px;
`;
const Conatiner = styled.div`
    display: flex;
    width: 50%;
    justify-content: space-between;
`;
const Header = styled.h4``;

const Heading = styled.div`
    width: 7%;
    font-size: 16px;
`;
const Lis = styled.li`
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    padding: 10px;
    border-radius: 10px;
    background: #fff;
    p {
        font-size: 18px;
    }
`;
const Box = styled.div`
    padding: 8px;
    display: flex;
    width: 35px;
    height: 20px;
    border: 1px solid black;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    &:hover {
        border: 1px solid #746bb7;
    }
`;
const Right = styled.div`
    display: flex;
    width: 15%;
    justify-content: flex-end;
`;
const Radio = styled.div`
    margin-right: 20px;
`;
const EditContainer = styled.div`
    width: 10%;
    cursor: pointer;
`;
const Buttons = styled.div`
    display: flex;
    justify-content: flex-end;
    padding-top: 20px;
    width: 95%;
`;
const Button = styled.div`
    padding: 10px;
    display: flex;
    width: 120px;
    border-radius: 8px;
    background: #41369f;
    color: #fff;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    &.first {
        margin-right: 10px;
        background: #e9e9e9;
        color: #000;
    }
`;
