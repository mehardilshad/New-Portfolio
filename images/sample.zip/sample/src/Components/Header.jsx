import React from "react";
import { Link, Outlet } from "react-router-dom";
import styled from "styled-components";

function Header() {
  const data = [
    {
      id: 1,
      para: "Checkout Steps",
      pic:require("../../src/Images/icons8-basket-24.png"),
      links: "/",
    },
    {
      id: 2,
      para: "Display",
      pic:require("../../src/Images/monitor.png"),
      links: '/display'
    },
    {
      id: 3,
      para: "Checkout Steps",
      pic:require("../../src/Images/settings.png"),
      links: '/display/'
    },
    {
      id: 4,
      para: "Checkout Steps",
      pic:require("../../src/Images/button-press.png"),
      links: '/display/',

    },
    {
      id: 5,
      para: "Checkout Steps",
      pic:require("../../src/Images/key.png"),
      links: '/display/'
    },
  ];
  return (
    <>
    
      <Wrapper className="wrapper">
        <MainContainer>
          {data.map((item) => (
            <Container >
                <Content key={item.id} to={item.links}>
                    <ImageContiane><img src={item.pic}/></ImageContiane>
                    <p>{item.para}</p>
                </Content>
            </Container>
          ))}
        </MainContainer>
        <Newstep>
          <p>Add New Step</p>
          <PlusContainer ><img src={require('../Images/add.png')} alt="key"/></PlusContainer>        </Newstep>
      </Wrapper>
      <Outlet/>
      
    </>
  );
}

export default Header;

const Wrapper = styled.div``;
const MainContainer = styled.h3`
  padding-top: 40px;
  width: 60%;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
`;
const Container =  styled.div`
    margin-right: 15px;
`;
const Content = styled(Link)`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 15px 5px;
    width: 160px;
  background: #fff;
  border-radius: 7px;
  border: 1px solid #fff;
  &:hover{
    border: 1px solid #6552fd;
  }
  p{
    font-size: 14px;
    .active{
      color: #6552fd;
    }
  }
`;
const ImageContiane = styled.div`
  width: 15%;
  margin-right: 10px;
`;
const Newstep = styled.div`
  width: 100%;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  cursor: pointer;
  p{
    margin-right: 10px;
    font-size: 16px;
    color: #746bb7;
  }
`;
const PlusContainer = styled.div`
  width: 2%;
`;
