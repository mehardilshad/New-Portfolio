import React from 'react'

export default function Display() {
  return (
    <div className='Spotlight'>Display hello</div>
  )
}
