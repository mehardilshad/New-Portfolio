import Header from "./Components/Header";
import "./Css/style.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Spotlight from "./Components/Spotlight";
import Display from "./screens/Display";
import Modal from "./Components/Modal";

function App() {
    return (
        <>
            <Router>
                <Routes>
                    <Route path="/" element={<Header />}>
                        <Route path="/" element={<Spotlight />} />
                        <Route path="/display" element={<Display />} />
                    </Route>
                    <Route path="/Edit" element={< Modal/>} />
                </Routes>
            </Router>
        </>
    );
}

export default App;
